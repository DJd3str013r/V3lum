# example-repo

Synthetic fixture for org_code_footprint.
