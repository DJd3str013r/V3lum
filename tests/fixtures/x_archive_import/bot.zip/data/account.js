window.YTD.account.part0 = [
  {
    "account": {
      "username": "fakebot_123456",
      "accountId": "1000000000000000002",
      "createdAt": "2026-09-01T00:00:00.000Z",
      "accountDisplayName": "Example Bot"
    }
  }
]