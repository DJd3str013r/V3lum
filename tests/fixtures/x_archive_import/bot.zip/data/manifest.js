window.__THAR_CONFIG = {
  "userInfo": {
    "accountId": "1000000000000000002",
    "userName": "fakebot_123456",
    "displayName": "Example Bot"
  },
  "archiveInfo": {
    "sizeBytes": "123456",
    "generationDate": "2026-10-01T12:00:00.000Z",
    "isPartialArchive": false,
    "maxPartSizeBytes": "53687091200"
  },
  "dataTypes": {
    "tweets": {
      "files": [
        {
          "fileName": "data/tweets.js",
          "globalName": "YTD.tweets.part0",
          "count": "60"
        }
      ]
    }
  }
}