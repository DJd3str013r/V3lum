window.YTD.tweets.part0 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104722825016246272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104722825016246272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104722825016246272",
      "created_at": "Tue Sep 29 00:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 0",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104730374763446273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104730374763446273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104730374763446273",
      "created_at": "Tue Sep 29 00:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 1",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104737924510646274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104737924510646274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104737924510646274",
      "created_at": "Tue Sep 29 01:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 2",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104745474257846275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104745474257846275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104745474257846275",
      "created_at": "Tue Sep 29 01:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 3",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104753024005046276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104753024005046276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104753024005046276",
      "created_at": "Tue Sep 29 02:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 4",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104760573752246277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104760573752246277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104760573752246277",
      "created_at": "Tue Sep 29 02:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 5",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104768123499446278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104768123499446278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104768123499446278",
      "created_at": "Tue Sep 29 03:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 6",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104775673246646272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104775673246646272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104775673246646272",
      "created_at": "Tue Sep 29 03:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 7",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104783222993846273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104783222993846273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104783222993846273",
      "created_at": "Tue Sep 29 04:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 8",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104790772741046274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2104790772741046274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104790772741046274",
      "created_at": "Tue Sep 29 04:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 9",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104798322488246275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104798322488246275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104798322488246275",
      "created_at": "Tue Sep 29 05:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 10",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104805872235446276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104805872235446276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104805872235446276",
      "created_at": "Tue Sep 29 05:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 11",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104813421982646277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104813421982646277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104813421982646277",
      "created_at": "Tue Sep 29 06:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 12",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104820971729846278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104820971729846278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104820971729846278",
      "created_at": "Tue Sep 29 06:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 13",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104828521477046272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104828521477046272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104828521477046272",
      "created_at": "Tue Sep 29 07:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 14",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104836071224246273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104836071224246273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104836071224246273",
      "created_at": "Tue Sep 29 07:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 15",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104843620971446274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104843620971446274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104843620971446274",
      "created_at": "Tue Sep 29 08:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 16",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104851170718646275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104851170718646275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104851170718646275",
      "created_at": "Tue Sep 29 08:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 17",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104858720465846276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104858720465846276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104858720465846276",
      "created_at": "Tue Sep 29 09:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 18",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104866270213046277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104866270213046277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104866270213046277",
      "created_at": "Tue Sep 29 09:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 19",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104873819960246278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104873819960246278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104873819960246278",
      "created_at": "Tue Sep 29 10:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 20",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104881369707446272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104881369707446272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104881369707446272",
      "created_at": "Tue Sep 29 10:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 21",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104888919454646273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104888919454646273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104888919454646273",
      "created_at": "Tue Sep 29 11:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 22",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104896469201846274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104896469201846274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104896469201846274",
      "created_at": "Tue Sep 29 11:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 23",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104904018949046275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104904018949046275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104904018949046275",
      "created_at": "Tue Sep 29 12:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 24",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104911568696246276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104911568696246276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104911568696246276",
      "created_at": "Tue Sep 29 12:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 25",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104919118443446277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104919118443446277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104919118443446277",
      "created_at": "Tue Sep 29 13:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 26",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104926668190646278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104926668190646278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104926668190646278",
      "created_at": "Tue Sep 29 13:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 27",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104934217937846272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104934217937846272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104934217937846272",
      "created_at": "Tue Sep 29 14:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 28",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104941767685046273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104941767685046273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104941767685046273",
      "created_at": "Tue Sep 29 14:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 29",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104949317432246274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104949317432246274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104949317432246274",
      "created_at": "Tue Sep 29 15:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 30",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104956867179446275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104956867179446275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104956867179446275",
      "created_at": "Tue Sep 29 15:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 31",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104964416926646276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104964416926646276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104964416926646276",
      "created_at": "Tue Sep 29 16:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 32",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104971966673846277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104971966673846277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104971966673846277",
      "created_at": "Tue Sep 29 16:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 33",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104979516421046278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104979516421046278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104979516421046278",
      "created_at": "Tue Sep 29 17:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 34",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104987066168246272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104987066168246272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104987066168246272",
      "created_at": "Tue Sep 29 17:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 35",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2104994615915446273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2104994615915446273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2104994615915446273",
      "created_at": "Tue Sep 29 18:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 36",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105002165662646274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105002165662646274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105002165662646274",
      "created_at": "Tue Sep 29 18:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 37",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105009715409846275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105009715409846275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105009715409846275",
      "created_at": "Tue Sep 29 19:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 38",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105017265157046276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105017265157046276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105017265157046276",
      "created_at": "Tue Sep 29 19:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 39",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105024814904246277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105024814904246277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105024814904246277",
      "created_at": "Tue Sep 29 20:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 40",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105032364651446278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105032364651446278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105032364651446278",
      "created_at": "Tue Sep 29 20:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 41",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105039914398646272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105039914398646272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105039914398646272",
      "created_at": "Tue Sep 29 21:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 42",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105047464145846273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105047464145846273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105047464145846273",
      "created_at": "Tue Sep 29 21:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 43",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105055013893046274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105055013893046274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105055013893046274",
      "created_at": "Tue Sep 29 22:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 44",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105062563640246275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105062563640246275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105062563640246275",
      "created_at": "Tue Sep 29 22:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 45",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105070113387446276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105070113387446276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105070113387446276",
      "created_at": "Tue Sep 29 23:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 46",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105077663134646277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105077663134646277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105077663134646277",
      "created_at": "Tue Sep 29 23:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 47",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105085212881846278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105085212881846278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105085212881846278",
      "created_at": "Wed Sep 30 00:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 48",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105092762629046272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105092762629046272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105092762629046272",
      "created_at": "Wed Sep 30 00:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 49",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105100312376246273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105100312376246273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105100312376246273",
      "created_at": "Wed Sep 30 01:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 50",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105107862123446274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105107862123446274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105107862123446274",
      "created_at": "Wed Sep 30 01:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 51",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105115411870646275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105115411870646275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105115411870646275",
      "created_at": "Wed Sep 30 02:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 52",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105122961617846276"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105122961617846276",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105122961617846276",
      "created_at": "Wed Sep 30 02:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 53",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105130511365046277"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105130511365046277",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105130511365046277",
      "created_at": "Wed Sep 30 03:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 54",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105138061112246278"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105138061112246278",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105138061112246278",
      "created_at": "Wed Sep 30 03:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 55",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105145610859446272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105145610859446272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105145610859446272",
      "created_at": "Wed Sep 30 04:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 56",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105153160606646273"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105153160606646273",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105153160606646273",
      "created_at": "Wed Sep 30 04:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 57",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105160710353846274"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105160710353846274",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105160710353846274",
      "created_at": "Wed Sep 30 05:00:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 58",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2105168260101046275"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://example.com/autoposter\" rel=\"nofollow\">ExampleAutoPoster</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_source",
            "screen_name": "example_source",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "27"
      ],
      "favorite_count": "0",
      "id_str": "2105168260101046275",
      "truncated": false,
      "retweet_count": "0",
      "id": "2105168260101046275",
      "created_at": "Wed Sep 30 05:30:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_source: item 59",
      "lang": "pt"
    }
  }
]