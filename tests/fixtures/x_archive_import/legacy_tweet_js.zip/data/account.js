window.YTD.account.part0 = [
  {
    "account": {
      "email": "owner@example.com",
      "createdVia": "web",
      "username": "exampleorg",
      "accountId": "1000000000000000001",
      "createdAt": "2015-05-02T10:00:00.000Z",
      "accountDisplayName": "Example Org"
    }
  }
]