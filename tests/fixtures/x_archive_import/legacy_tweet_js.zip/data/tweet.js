window.YTD.tweet.part0 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062134197744566272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/0",
            "display_url": "example.com/n/0",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062134197744566272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062134197744566272",
      "created_at": "Wed Jun 03 11:28:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 0 sobre o servico #ExemploSA https://example.com/n/0",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062189310899126272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/1",
            "display_url": "example.com/n/1",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062189310899126272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062189310899126272",
      "created_at": "Wed Jun 03 15:07:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 1 sobre o servico #ExemploSA https://example.com/n/1",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062278397916086272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/2",
            "display_url": "example.com/n/2",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062278397916086272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062278397916086272",
      "created_at": "Wed Jun 03 21:01:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 2 sobre o servico #ExemploSA https://example.com/n/2",
      "lang": "pt"
    }
  }
]