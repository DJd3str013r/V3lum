window.YTD.deleted_tweets.part0 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062504638673846272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "26"
      ],
      "favorite_count": "0",
      "id_str": "2062504638673846272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062504638673846272",
      "created_at": "Thu Jun 04 12:00:00 +0000 2026",
      "favorited": false,
      "full_text": "Post removido pelo titular",
      "lang": "pt",
      "deleted_at": "Fri Jun 05 12:00:00 +0000 2026"
    }
  }
]