window.YTD.ip_audit.part0 = [
  {
    "ipAudit": {
      "accountId": "1",
      "loginIp": "192.0.2.10"
    }
  }
]