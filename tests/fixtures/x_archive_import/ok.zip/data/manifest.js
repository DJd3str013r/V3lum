window.__THAR_CONFIG = {
  "userInfo": {
    "accountId": "1000000000000000001",
    "userName": "exampleorg",
    "displayName": "Example Org"
  },
  "archiveInfo": {
    "sizeBytes": "123456",
    "generationDate": "2026-10-01T12:00:00.000Z",
    "isPartialArchive": false,
    "maxPartSizeBytes": "53687091200"
  },
  "dataTypes": {
    "tweets": {
      "files": [
        {
          "fileName": "data/tweets.js",
          "globalName": "YTD.tweets.part0",
          "count": "20"
        },
        {
          "fileName": "data/tweets-part1.js",
          "globalName": "YTD.tweets.part1",
          "count": "10"
        }
      ]
    }
  }
}