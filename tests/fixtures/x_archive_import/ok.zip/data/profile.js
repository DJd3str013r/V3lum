window.YTD.profile.part0 = [
  {
    "profile": {
      "description": {
        "bio": "Conta oficial da Exemplo S.A.",
        "website": "https://example.com",
        "location": "Sao Paulo, Brasil"
      },
      "avatarMediaUrl": "https://pbs.twimg.com/profile_images/1000000000000000000/example.jpg",
      "headerMediaUrl": "https://pbs.twimg.com/profile_banners/1000000000000000001/1600000000"
    }
  }
]