window.YTD.tweets.part1 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2067793991562166272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/20",
            "display_url": "example.com/n/20",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2067793991562166272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2067793991562166272",
      "created_at": "Fri Jun 19 02:18:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 20 sobre o servico #ExemploSA https://example.com/n/20",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2067931900277686272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/21",
            "display_url": "example.com/n/21",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2067931900277686272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2067931900277686272",
      "created_at": "Fri Jun 19 11:26:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 21 sobre o servico #ExemploSA https://example.com/n/21",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2068153107870646272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/22",
            "display_url": "example.com/n/22",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2068153107870646272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2068153107870646272",
      "created_at": "Sat Jun 20 02:05:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 22 sobre o servico #ExemploSA https://example.com/n/22",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2068679073592246272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_news",
            "screen_name": "example_news",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "42"
      ],
      "favorite_count": "0",
      "id_str": "2068679073592246272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2068679073592246272",
      "created_at": "Sun Jun 21 12:55:00 +0000 2026",
      "favorited": false,
      "full_text": "@example_news obrigado pela cobertura (23)",
      "lang": "pt",
      "in_reply_to_screen_name": "example_news",
      "in_reply_to_status_id_str": "1"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2069398564500406272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/24",
            "display_url": "example.com/n/24",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2069398564500406272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2069398564500406272",
      "created_at": "Tue Jun 23 12:34:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 24 sobre o servico #ExemploSA https://example.com/n/24",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2069797442810806272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/25",
            "display_url": "example.com/n/25",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2069797442810806272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2069797442810806272",
      "created_at": "Wed Jun 24 14:59:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 25 sobre o servico #ExemploSA https://example.com/n/25",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2070513913820086272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/26",
            "display_url": "example.com/n/26",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2070513913820086272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2070513913820086272",
      "created_at": "Fri Jun 26 14:26:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 26 sobre o servico #ExemploSA https://example.com/n/26",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2070602749178806272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/27",
            "display_url": "example.com/n/27",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2070602749178806272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2070602749178806272",
      "created_at": "Fri Jun 26 20:19:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 27 sobre o servico #ExemploSA https://example.com/n/27",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2071202954081206272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/28",
            "display_url": "example.com/n/28",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2071202954081206272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2071202954081206272",
      "created_at": "Sun Jun 28 12:04:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 28 sobre o servico #ExemploSA https://example.com/n/28",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2071256053969846272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/29",
            "display_url": "example.com/n/29",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2071256053969846272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2071256053969846272",
      "created_at": "Sun Jun 28 15:35:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 29 sobre o servico #ExemploSA https://example.com/n/29",
      "lang": "pt"
    }
  }
]