window.YTD.tweets.part0 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062134197744566272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/0",
            "display_url": "example.com/n/0",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062134197744566272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062134197744566272",
      "created_at": "Wed Jun 03 11:28:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 0 sobre o servico #ExemploSA https://example.com/n/0",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062189310899126272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/1",
            "display_url": "example.com/n/1",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062189310899126272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062189310899126272",
      "created_at": "Wed Jun 03 15:07:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 1 sobre o servico #ExemploSA https://example.com/n/1",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062278397916086272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/2",
            "display_url": "example.com/n/2",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062278397916086272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062278397916086272",
      "created_at": "Wed Jun 03 21:01:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 2 sobre o servico #ExemploSA https://example.com/n/2",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062585420968886272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/3",
            "display_url": "example.com/n/3",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2062585420968886272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062585420968886272",
      "created_at": "Thu Jun 04 17:21:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 3 sobre o servico #ExemploSA https://example.com/n/3",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2062927676175286272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_agency",
            "screen_name": "example_agency",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "42"
      ],
      "favorite_count": "0",
      "id_str": "2062927676175286272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2062927676175286272",
      "created_at": "Fri Jun 05 16:01:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_agency: Aviso publico numero 4",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2063231176012726272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/5",
            "display_url": "example.com/n/5",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2063231176012726272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2063231176012726272",
      "created_at": "Sat Jun 06 12:07:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 5 sobre o servico #ExemploSA https://example.com/n/5",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2063704796820406272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/6",
            "display_url": "example.com/n/6",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2063704796820406272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2063704796820406272",
      "created_at": "Sun Jun 07 19:29:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 6 sobre o servico #ExemploSA https://example.com/n/6",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2064045542077366272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_news",
            "screen_name": "example_news",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "41"
      ],
      "favorite_count": "0",
      "id_str": "2064045542077366272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2064045542077366272",
      "created_at": "Mon Jun 08 18:03:00 +0000 2026",
      "favorited": false,
      "full_text": "@example_news obrigado pela cobertura (7)",
      "lang": "pt",
      "in_reply_to_screen_name": "example_news",
      "in_reply_to_status_id_str": "1"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2064310789862326272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/8",
            "display_url": "example.com/n/8",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2064310789862326272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2064310789862326272",
      "created_at": "Tue Jun 09 11:37:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 8 sobre o servico #ExemploSA https://example.com/n/8",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2064785165644726272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/9",
            "display_url": "example.com/n/9",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "0",
      "id_str": "2064785165644726272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2064785165644726272",
      "created_at": "Wed Jun 10 19:02:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 9 sobre o servico #ExemploSA https://example.com/n/9",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2065183540638646272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/10",
            "display_url": "example.com/n/10",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2065183540638646272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2065183540638646272",
      "created_at": "Thu Jun 11 21:25:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 10 sobre o servico #ExemploSA https://example.com/n/10",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2065402734965686272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_agency",
            "screen_name": "example_agency",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "43"
      ],
      "favorite_count": "0",
      "id_str": "2065402734965686272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2065402734965686272",
      "created_at": "Fri Jun 12 11:56:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_agency: Aviso publico numero 11",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2065487292134326272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/12",
            "display_url": "example.com/n/12",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2065487292134326272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2065487292134326272",
      "created_at": "Fri Jun 12 17:32:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 12 sobre o servico #ExemploSA https://example.com/n/12",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2065830805631926272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/13",
            "display_url": "example.com/n/13",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2065830805631926272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2065830805631926272",
      "created_at": "Sat Jun 13 16:17:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 13 sobre o servico #ExemploSA https://example.com/n/13",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2065911839585206272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/14",
            "display_url": "example.com/n/14",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2065911839585206272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2065911839585206272",
      "created_at": "Sat Jun 13 21:39:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 14 sobre o servico #ExemploSA https://example.com/n/14",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2066504746398646272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/15",
            "display_url": "example.com/n/15",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2066504746398646272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2066504746398646272",
      "created_at": "Mon Jun 15 12:55:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 15 sobre o servico #ExemploSA https://example.com/n/15",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2066901359784886272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/16",
            "display_url": "example.com/n/16",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2066901359784886272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2066901359784886272",
      "created_at": "Tue Jun 16 15:11:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 16 sobre o servico #ExemploSA https://example.com/n/16",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2066953201382326272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/17",
            "display_url": "example.com/n/17",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2066953201382326272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2066953201382326272",
      "created_at": "Tue Jun 16 18:37:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 17 sobre o servico #ExemploSA https://example.com/n/17",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2067255442928566272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [
          {
            "text": "ExemploSA",
            "indices": [
              "0",
              "1"
            ]
          }
        ],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/example",
            "expanded_url": "https://example.com/n/18",
            "display_url": "example.com/n/18",
            "indices": [
              "0",
              "1"
            ]
          }
        ]
      },
      "display_text_range": [
        "0",
        "66"
      ],
      "favorite_count": "0",
      "id_str": "2067255442928566272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2067255442928566272",
      "created_at": "Wed Jun 17 14:38:00 +0000 2026",
      "favorited": false,
      "full_text": "Atualizacao 18 sobre o servico #ExemploSA https://example.com/n/18",
      "lang": "pt"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "2067398636467126272"
          ],
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "name": "example_agency",
            "screen_name": "example_agency",
            "indices": [
              "0",
              "1"
            ],
            "id_str": "0",
            "id": "0"
          }
        ],
        "urls": []
      },
      "display_text_range": [
        "0",
        "43"
      ],
      "favorite_count": "0",
      "id_str": "2067398636467126272",
      "truncated": false,
      "retweet_count": "0",
      "id": "2067398636467126272",
      "created_at": "Thu Jun 18 00:07:00 +0000 2026",
      "favorited": false,
      "full_text": "RT @example_agency: Aviso publico numero 19",
      "lang": "pt"
    }
  }
]